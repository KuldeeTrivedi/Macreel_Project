﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Macreel_Project.Models.Admin
{
    public class packing_model
    {
    }
}